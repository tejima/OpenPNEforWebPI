<?php
/**
 * @copyright 2005-2008 OpenPNE Project
 * @license   http://www.php.net/license/3_01.txt PHP License 3.01
 */

define('OPENPNE_DIR', realpath('../'));
require_once OPENPNE_DIR . '/config.php';

?>
