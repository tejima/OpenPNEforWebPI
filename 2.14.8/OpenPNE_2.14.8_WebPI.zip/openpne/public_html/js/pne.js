
function pne_url2a(url){var urlstr=url.replace("&amp;","&");if(urlstr.length>57){urlstr=urlstr.substr(0,57)+'...';}
urlstr=urlstr.replace("&","&amp;");document.write('<a href="'+url+'" target="_blank">'+urlstr+'</a>');}