このディレクトリには、バージョンアップに伴い必要となるコンバートを行うスクリプトを格納しています。

config.phpの設定を行ったのちにスクリプトを実行してください。

■update01-for2.13.8-insert_image_size.php
  2.13.8で追加された「画像アップロードサイズ制限機能」の対応で
  アップロード済み画像のサイズデータを反映させるスクリプトです。

実行方法：
  OPENPNE_DIR/setup/script/update/ にて、以下のコマンドを実行します。
  php update01-for2.13.8-insert_image_size.php

